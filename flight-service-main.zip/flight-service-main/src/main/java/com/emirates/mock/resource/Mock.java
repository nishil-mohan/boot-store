package com.emirates.mock.resource;

public class Mock {
	
	private String message;
	
	public Mock() {
		
	}

	public Mock(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
