package com.emirates.mock.resource;

import java.time.Duration;
import java.util.Random;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import reactor.core.publisher.Mono;

@Component
public class RouteHandlers {

  Random rand = new Random();

  public Mono<ServerResponse> getMockOne(ServerRequest serverRequest) {

    return ServerResponse.ok().body(
        Mono.just(new Mock("mock1")).delayElement(Duration.ofMillis(getRandomDelay())), Mock.class);
  }

  public Mono<ServerResponse> getMockTwo(ServerRequest serverRequest) {

    return ServerResponse.ok().body(
        Mono.just(new Mock("mock2")).delayElement(Duration.ofMillis(getRandomDelay())), Mock.class);
  }

  public Mono<ServerResponse> getMockThree(ServerRequest serverRequest) {

    return ServerResponse.ok().body(
        Mono.just(new Mock("mock3")).delayElement(Duration.ofMillis(getRandomDelay())), Mock.class);
  }

  public Mono<ServerResponse> getMockFour(ServerRequest serverRequest) {

    return ServerResponse.ok().body(
        Mono.just(new Mock("mock4")).delayElement(Duration.ofMillis(getRandomDelay())), Mock.class);
  }

  public Mono<ServerResponse> getMockFive(ServerRequest serverRequest) {

    return ServerResponse.ok().body(
        Mono.just(new Mock("mock5")).delayElement(Duration.ofMillis(getRandomDelay())), Mock.class);
  }

  private int getRandomDelay() {
    int lowerBound = 500;
    int upperBound = 800;
    return rand.nextInt(upperBound - lowerBound) + lowerBound;
  }

}
