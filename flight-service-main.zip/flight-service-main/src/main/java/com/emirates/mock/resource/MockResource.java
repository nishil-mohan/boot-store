package com.emirates.mock.resource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;


@Configuration
public class MockResource {
	
	@Bean
	RouterFunction<ServerResponse> routerFunction(RouteHandlers routeHandlers){
		
		return RouterFunctions.route(				
				RequestPredicates.GET("/mock/one"),routeHandlers::getMockOne)
				.andRoute(RequestPredicates.GET("/mock/two"),routeHandlers::getMockTwo)
				.andRoute(RequestPredicates.GET("/mock/three"),routeHandlers::getMockThree)
				.andRoute(RequestPredicates.GET("/mock/four"),routeHandlers::getMockFour)
				.andRoute(RequestPredicates.GET("/mock/five"),routeHandlers::getMockFive);		
	}

}
