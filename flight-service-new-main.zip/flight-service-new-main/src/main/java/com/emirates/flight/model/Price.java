package com.emirates.flight.model;

import java.math.BigDecimal;

public class Price {

  private BigDecimal baseFare;
  private BigDecimal tax;
  private BigDecimal totalFare;
  
  public BigDecimal getBaseFare() {
    return baseFare;
  }
  public void setBaseFare(BigDecimal baseFare) {
    this.baseFare = baseFare;
  }
  public BigDecimal getTax() {
    return tax;
  }
  public void setTax(BigDecimal tax) {
    this.tax = tax;
  }
  public BigDecimal getTotalFare() {
    return totalFare;
  }
  public void setTotalFare(BigDecimal totalFare) {
    this.totalFare = totalFare;
  }
  
  public Price() {
    super();
  }
  public Price(BigDecimal baseFare, BigDecimal tax, BigDecimal totalFare) {
    super();
    this.baseFare = baseFare;
    this.tax = tax;
    this.totalFare = totalFare;
  }
  
  

}
