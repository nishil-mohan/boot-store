package com.emirates.flight.handler;

import com.emirates.flight.model.Flight;
import com.emirates.flight.model.FlightEvent;
import com.emirates.flight.model.Price;
import com.emirates.flight.repository.FlightRepository;
import com.emirates.flight.service.FlightService;
import com.emirates.flight.service.MockService;
import com.emirates.flight.service.PriceService;

import java.time.Duration;
import java.util.Date;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

@Component
public class RouteHandlers {
	
	private static final Logger log = LoggerFactory.getLogger(RouteHandlers.class);
	
	@Autowired
	private FlightRepository flightRepository;	
	
	@Autowired
    private FlightService flightService;  
	
	@Autowired
    private PriceService priceService; 
	

	public Mono<ServerResponse> getAll(ServerRequest serverRequest){
		return ServerResponse.ok()
				.body(flightRepository.findAll(),Flight.class);
	}
	
    public Mono<ServerResponse> getId(ServerRequest serverRequest){
	  Long id = Long.valueOf(serverRequest.pathVariable("id"));	
		return ServerResponse.ok()
				.body(flightRepository.findById(id),Flight.class);		
	}
	
    public Mono<ServerResponse> getFlight(ServerRequest serverRequest){
		String flightdate = serverRequest.pathVariable("flightdate");	
		String origin = serverRequest.pathVariable("origin");		
		String destination = serverRequest.pathVariable("destination");		
		return ServerResponse.ok()
				.body(flightService.getFlight(flightdate, origin, destination),Flight.class);		
	}
    
    public Mono<ServerResponse> getPrice(ServerRequest serverRequest){
      String flightNumber = serverRequest.pathVariable("flightnumber");   
      String flightdate = serverRequest.pathVariable("flightdate");    
      Price price = priceService.getPrice(flightNumber, flightdate);
      if (price == null) {
        return ServerResponse.notFound().build();
      }
      return ServerResponse.ok()
              .body(Mono.just(priceService.getPrice(flightNumber, flightdate)),Price.class);       
  }

	public Mono<ServerResponse> getFlightEvents(ServerRequest serverRequest){
		Long id = Long.valueOf(serverRequest.pathVariable("id"));		
		return ServerResponse.ok()
				.contentType(MediaType.TEXT_EVENT_STREAM)
		.body(flightRepository.findById(id)
				.flatMapMany(flight ->{					
					Flux<Long> interval = Flux.interval(Duration.ofMillis(500));					
					Flux<FlightEvent> flightEventFlux = Flux.fromStream(Stream.generate(()->new FlightEvent(flight, new Date())));					
					return Flux.zip(interval, flightEventFlux).map(Tuple2::getT2);
					
				}),FlightEvent.class);		
	}
	

}
