package com.emirates.flight.service;

import com.emirates.flight.model.Flight;
import com.emirates.flight.model.FlightDetails;
import com.emirates.flight.repository.FlightRepository;
import com.emirates.flight.vo.Mock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Service
public class FlightService {
  
  @Autowired
  private FlightRepository flightRepository;  
  
  @Autowired
  private MockService mockService;  
	
    //@Cacheable("flightCache")
	public Mono<FlightDetails> getFlight(String flightdate, String  origin,String  destination){
	  // Call 5 mock services in nonblocking and subscribe to another thread
	  Mono<Mock> mockOne = mockService.getMockResponse("one").subscribeOn(Schedulers.boundedElastic());
      Mono<Mock> mockTwo = mockService.getMockResponse("two").subscribeOn(Schedulers.boundedElastic());
      Mono<Mock> mockThree = mockService.getMockResponse("three").subscribeOn(Schedulers.boundedElastic());
      Mono<Mock> mockFour = mockService.getMockResponse("four").subscribeOn(Schedulers.boundedElastic());
      Mono<Mock> mockFive = mockService.getMockResponse("five").subscribeOn(Schedulers.boundedElastic());
     
      Mono<Flight> flight = flightRepository.findByFlightdateAndOriginAndDestination(flightdate, origin, destination);
      // Merge the monos to a new Mono
      return Mono.zip(mockOne, mockTwo,mockThree, mockFour, mockFive, flight).map(entry->
        new FlightDetails(entry.getT6(),entry.getT1(),entry.getT2(),entry.getT3(),entry.getT4(),entry.getT5())
      ); 
      
	}

}
