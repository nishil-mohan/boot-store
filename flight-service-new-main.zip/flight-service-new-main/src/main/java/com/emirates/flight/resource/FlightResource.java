/*package com.emirates.flight.resource;

import java.time.Duration;
import java.util.Date;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emirates.flight.model.Flight;
import com.emirates.flight.model.FlightEvent;
import com.emirates.flight.repository.FlightRepository;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

@RestController
@Slf4j
@RequestMapping("/")
public class FlightResource {
	
	private static final Logger log = LoggerFactory.getLogger(FlightResource.class);
	
	@Autowired
	private FlightRepository flightRepository;
	
	@GetMapping("/flight/all")
	public Flux<Flight> getAllFlights(){
		return flightRepository.findAll();
	}
	
	@GetMapping("/flight/{id}")
	public Mono<Flight> getFlightWithId(@PathVariable("id") Long id){
		return flightRepository.findById(id);
	}
	
	@PostMapping("/flight")
	public Mono<Flight> getFlight(@RequestBody Flight flight){
		return flightRepository.findById(flight.getId());
	}
	
	@GetMapping("/flight/{flightdate}/{origin}/{destination}")
	public Mono<Flight> getFlightDetails(@PathVariable("flightdate") String flightdate,@PathVariable("origin") String origin,
			@PathVariable("destination") String destination){
		return flightRepository.findByFlightdateAndOriginAndDestination(flightdate,origin,destination);
	}
	
	
	@PostMapping("/flight")
	public Mono<Flight> getFlightDetails(@RequestBody Flight flight){	
				
		return flightRepository.findByFlightdateAndOriginAndDestination(flight.getFlightdate(),flight.getOrigin(),flight.getDestination());
	}
		
	

	@GetMapping(value="/flight/{flightdate}/{origin}/{destination}/events",produces=MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<FlightEvent> getFlightWithId(@PathVariable("flightdate") String flightdate,@PathVariable("origin") String origin,
			@PathVariable("destination") String destination){
		return flightRepository.findByFlightdateAndOriginAndDestination(flightdate,origin,destination)
				.flatMapMany(flight ->{
			
			log.info("flightdate {}",flightdate);
			log.info("origin {}",origin);
			log.info("destination {}",destination);
					
			Flux<Long> interval = Flux.interval(Duration.ofMillis(500));
			
			log.info("After 500ms");
			
			Flux<FlightEvent> flightEventFlux = Flux.fromStream(Stream.generate(()->new FlightEvent(flight, new Date())));
			
			log.info("Fetched data");
			
			return Flux.zip(interval, flightEventFlux).map(Tuple2::getT2);
			
		});
		
	}
	
	
	@GetMapping(value="/flight/{id}/events",produces=MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<FlightEvent> getAllFlights(@PathVariable("id") Long id){
		
		return flightRepository.findById(id)
		.flatMapMany(flight ->{
			
			Flux<Long> interval = Flux.interval(Duration.ofMillis(500));
			
			Flux<FlightEvent> flightEventFlux = Flux.fromStream(Stream.generate(()->new FlightEvent(flight, new Date())));
			
			return Flux.zip(interval, flightEventFlux).map(Tuple2::getT2);
			
		});
		
	}

}
*/