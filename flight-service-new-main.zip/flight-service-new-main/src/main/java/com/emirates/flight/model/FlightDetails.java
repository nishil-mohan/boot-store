package com.emirates.flight.model;

import com.emirates.flight.vo.Mock;

import java.util.List;

public class FlightDetails {

  private Flight flight;
  private Mock mockOne;
  private Mock mockTwo;
  private Mock mockThree;
  private Mock mockFour;
  private Mock mockFive;

  public FlightDetails() {

  }

  public FlightDetails(Flight flight, Mock mockOne, Mock mockTwo, Mock mockThree, Mock mockFour,
      Mock mockFive) {
    this.flight = flight;
    this.mockOne = mockOne;
    this.mockTwo = mockTwo;
    this.mockThree = mockThree;
    this.mockFour = mockFour;
    this.mockFive = mockFive;

  }


  public Flight getFlight() {
    return flight;
  }

  public void setFlight(Flight flight) {
    this.flight = flight;
  }

  public Mock getMockOne() {
    return mockOne;
  }

  public void setMockOne(Mock mockOne) {
    this.mockOne = mockOne;
  }

  public Mock getMockTwo() {
    return mockTwo;
  }

  public void setMockTwo(Mock mockTwo) {
    this.mockTwo = mockTwo;
  }

  public Mock getMockThree() {
    return mockThree;
  }

  public void setMockThree(Mock mockThree) {
    this.mockThree = mockThree;
  }

  public Mock getMockFour() {
    return mockFour;
  }

  public void setMockFour(Mock mockFour) {
    this.mockFour = mockFour;
  }

  public Mock getMockFive() {
    return mockFive;
  }

  public void setMockFive(Mock mockFive) {
    this.mockFive = mockFive;
  }

  

}
