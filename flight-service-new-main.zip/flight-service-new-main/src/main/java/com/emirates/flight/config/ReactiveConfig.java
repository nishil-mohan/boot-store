package com.emirates.flight.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.emirates.flight.handler.RouteHandlers;

@Configuration
public class ReactiveConfig {
	
	@Bean
	RouterFunction<ServerResponse> routerFunction(RouteHandlers routeHandlers){
		
		return RouterFunctions.route(				
				RequestPredicates.GET("/flight/all"),routeHandlers::getAll)
				.andRoute(RequestPredicates.GET("/flight/{id}"),routeHandlers::getId)
				.andRoute(RequestPredicates.GET("/flight/{id}/events"),routeHandlers::getFlightEvents)
				.andRoute(RequestPredicates.GET("/flight/{flightdate}/{origin}/{destination}"),routeHandlers::getFlight)
				.andRoute(RequestPredicates.GET("/price/{flightnumber}/{flightdate}"),routeHandlers::getPrice);		
	}

}
