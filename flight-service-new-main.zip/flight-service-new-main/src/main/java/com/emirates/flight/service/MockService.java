package com.emirates.flight.service;

import com.emirates.flight.vo.Mock;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;

@Service
public class MockService {
	
    WebClient webClient = WebClient.create("http://localhost:8081");

	public Mono<Mock> getMockResponse(String mockId){
	  return webClient.get()
	        .uri("/mock/{id}", mockId)
	        .retrieve()
	        .bodyToMono(Mock.class);
	}

}
